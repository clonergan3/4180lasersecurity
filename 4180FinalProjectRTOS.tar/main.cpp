
#include "PwmOut.h"
#include "rtos.h"
#include "SDFileSystem.h"
#include "wave_player.h"
#include "uLCD_4DGL.h"
#include "stdio.h"


uLCD_4DGL LCD(p9,p10,p21);

SDFileSystem sd(p11, p12, p13, p22, "sd"); //SD card

AnalogOut DACout(p18);

PwmOut red(p25);
PwmOut green(p24);
PwmOut blue(p23);

wave_player waver(&DACout);

Serial bluetooth(p28,p27);

DigitalOut activate_camera(p19);

DigitalOut sd_enable(p30);

InterruptIn light_detect(p15);

uLCD_4DGL* LCD_ptr;

Mutex lcd_mutex;

Timer countdownTimer;
Timer ledtimer;
Timer trip_debounce;

volatile int mode = 1;

//modes:
//  1: Disarmed
//  2: Armed
//  3: Temporarily Disarmed for 10s
//  4: Alarm Triggered

int ledOn;

volatile int modechangeled = 1;
volatile int modechangelcd = 1;

volatile int silentAlarm;

volatile int intruderCount;

volatile int allow_trigger = 1;


RawSerial pc(USBTX, USBRX);

void trigger_alarm() {
    if (allow_trigger) {
        if (mode == 2 || mode == 4) {
            intruderCount++;
            mode = 4;
            modechangelcd = 1;
            activate_camera = 1;
            wait_us(100000);
            activate_camera = 0;
            ledtimer.start();
            lcd_mutex.lock();
            pc.printf("Alarm Triggered! \n");
            lcd_mutex.unlock();
        }
        trip_debounce.start();
        allow_trigger = 0;
    }
}

void set_led(int mode1) {
    switch (mode1) {
        case 1:
            red = 0;
            green = 1;
            blue = 0;
            break;
        case 2:
            red = 1;
            green = 0;
            blue = 0;
            break;
        case 3:
            red = 0;
            green = 1;
            blue = 0.5;
            break;
        case 4:
            red = 1;
            green = 0;
            blue = 0;
            break;
        case 5:
            red = 0;
            green = 0;
            blue = 0;
            break;
        default:
            red = 1;
            green = 1;
            blue = 1;
    }

}

void led_thread(void const *args) {
    while(1){
        if (modechangeled) {
            set_led(mode);
            modechangeled = 0;
        }
        else if (mode > 2) {
            if (!ledOn & ledtimer.read() > 0.5) {
                ledOn = 1;
                set_led(mode);
            }
            if (ledtimer.read() > 1) {
                ledOn = 0;
                set_led(5);
                ledtimer.reset();
                ledtimer.start();
            }
        }
        Thread::wait(50);
    }
}

void wav_thread(void const *args) {
    FILE *wave_file;
    while(1) {
        if (mode == 4 & !silentAlarm) {
            lcd_mutex.lock();
            sd_enable = 1;
            Thread::wait(2);
            sd_enable = 0;
            wave_file=fopen("/sd/alarm.wav","r");
            if(wave_file==NULL) printf("SD Access Error!\n\n\r");
            lcd_mutex.unlock();
            waver.play(wave_file);
            fclose(wave_file);
            Thread::wait(10);
        }
        else Thread::wait(100);
        
    }
}

void lcd_thread(void const *args) {
    LCD.cls();
    while(1) {
        if (modechangelcd) {
            switch(mode) {
                case 1:
                    lcd_mutex.lock();
                    LCD.cls();
                    //LCD.filled_rectangle(0, 0, 128, 128, WHITE);
                    //LCD.textbackground_color(WHITE);
                    LCD.locate(5,6);
                    LCD.color(GREEN);
                    LCD.printf("DISARMED");
                    LCD.locate(5,8);
                    LCD.color(0xFFFF00);
                    if (silentAlarm) LCD.printf("SILENT");
                    lcd_mutex.unlock();
                    break;
                case 2:
                    lcd_mutex.lock();
                    LCD.cls();
                    //LCD.filled_rectangle(0, 0, 128, 128, WHITE);
                    //LCD.textbackground_color(WHITE);
                    LCD.locate(5,6);
                    LCD.color(RED);
                    LCD.printf("ARMED");
                    LCD.locate(5,8);
                    LCD.color(0xFFFF00);
                    if (silentAlarm) LCD.printf("SILENT");
                    lcd_mutex.unlock();
                    break;
                case 3:
                    lcd_mutex.lock();
                    LCD.cls();
                    //LCD.filled_rectangle(0, 0, 128, 128, WHITE);
                    //LCD.textbackground_color(WHITE);
                    LCD.locate(3,6);
                    LCD.color(BLUE);
                    LCD.printf("ARMING in 10s");
                    lcd_mutex.unlock();
                    break;
                case 4: case 5:
                    lcd_mutex.lock();
                    LCD.cls();
                    //LCD.filled_rectangle(0, 0, 128, 128, WHITE);
                    //LCD.textbackground_color(WHITE);
                    LCD.locate(2,6);
                    LCD.color(RED);
                    LCD.printf("ALARM TRIGGERED");
                    LCD.locate(5,8);
                    LCD.printf("# Trips: %d", intruderCount);
                    lcd_mutex.unlock();
                    break;
            }
            modechangelcd = 0;
        }
        Thread::wait(50);
    }
    
}


void bluetooth_thread(void const *args) {
    
    while(1) {
        if(bluetooth.readable()) {
            lcd_mutex.lock();
            if (bluetooth.getc() == '1'){
                if (bluetooth.getc() == '3'){
                    if (bluetooth.getc() == '2'){
                        if (bluetooth.getc() == '4'){
                            bluetooth.getc();
                            char char_receive = bluetooth.getc();
                            switch(char_receive){
                                case '1': //disarm
                                    bluetooth.printf("disarmed! \n");
                                    mode = 1;
                                    modechangelcd = 1;
                                    modechangeled = 1;
                                    ledtimer.stop();
                                    intruderCount = 0;
                                    break;
                                case '2': //arm
                                    bluetooth.printf("armed! \n");
                                    mode = 2;
                                    modechangelcd = 1;
                                    modechangeled = 1;
                                    ledtimer.stop();
                                    intruderCount = 0;
                                    break;
                                case '3': //arm in 10s
                                    bluetooth.printf("Arming in 10 seconds! \n");
                                    modechangelcd = 1;
                                    mode = 3;
                                    countdownTimer.start();
                                    ledtimer.start();
                                    break;
                                case '4': //alarm trip
                                    bluetooth.printf("tripping alarm! \n");
                                    modechangelcd = 1;
                                    //mode = 2;
                                    //trigger_alarm();
                                    break;
                                case '5': //set to normal alarm
                                    bluetooth.printf("sound alarm mode! \n");
                                    silentAlarm = 0;
                                    modechangelcd = 1;
                                    break;
                                case '6': //set to silent alarm
                                    bluetooth.printf("silent alarm mode! \n");
                                    silentAlarm = 1;
                                    modechangelcd = 1;
                                    break;
                                default:
                                    bluetooth.printf("unknown command \n");
                            }
                        }
                    }
                }
            }
            bluetooth.getc();
            pc.printf("mode: %d \n", mode);
            lcd_mutex.unlock();
        }
        Thread::wait(100);
    }
    
}



int main()
{  
    pc.baud(9600);
    LCD.baudrate(1000000);
    light_detect.mode(PullUp);


    activate_camera = 0;

    sd_enable = 1;
    wait(0.01);
    sd_enable = 0;
    
    Thread t1(wav_thread);
    //t1.set_priority(osPriorityAboveNormal);
    Thread t2(lcd_thread);
    Thread t3(bluetooth_thread);
    Thread t4(led_thread);

    light_detect.fall(&trigger_alarm);

    while(1){
        if (countdownTimer.read() > 10) {
            countdownTimer.stop();
            countdownTimer.reset();
            mode = 2;
            modechangelcd = 1;
            modechangeled = 1;
        }
        if (trip_debounce.read() > 2) {
            trip_debounce.stop();
            trip_debounce.reset();
            allow_trigger = 1;
        }
        Thread::wait(100);
    }
}
